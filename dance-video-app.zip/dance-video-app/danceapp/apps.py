from django.apps import AppConfig


class DanceappConfig(AppConfig):
    name = 'danceapp'
